#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <mpi.h>

using namespace std;

// Function to calculate PI
long double calcPI(long double PI, long double n, long double sign, long double iterations)
{
    // Add for (iterations) 
    for (unsigned long int i = 0; i <= iterations; i++) {
        PI = PI + (sign * (4 / ((n) * (n + 1) * (n + 2))));
        // Add and sub
        // alt sequences
        sign = sign * (-1);
        // Increment by 2 according to Nilkantha’s formula
        n += 2;
    }
 
    // Return the value of Pi
    return PI;
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    const long double PI25DT = 3.141592653589793238462643383; // True value of pi

    if (argc != 2) {
        if (rank == 0) {
            cout << "Usage: " << argv[0] << " <iterations>" << endl;
        }
        MPI_Finalize();
        return 1;
    }

    long double iterations = stod(argv[1]);

    // Adjust chunk size based on the number of processors
    long double chunk_size = ceil(iterations / size);
    long double start = rank * chunk_size + 2; // Start iteration
    long double end = fmin((rank + 1) * chunk_size + 1, iterations); // End iteration

    auto start_time = chrono::steady_clock::now(); // Start time

    // Calculate local sum for each process
    long double local_sum = calcPI(start, end, 2 + rank, iterations);

    // Allocate buffer for receiving remote sum
    long double recv_sum;

    // Create MPI window for global sum
    MPI_Win win;
    MPI_Win_create(&recv_sum, sizeof(long double), sizeof(long double), MPI_INFO_NULL, MPI_COMM_WORLD, &win);

    // Start the first fence with a barrier
    MPI_Barrier(MPI_COMM_WORLD);

    // Use MPI_Put to accumulate local sums into global sum on rank 0
    if (rank == 0) {
        long double global_sum = local_sum;
        for (int i = 1; i < size; i++) {
            MPI_Put(&local_sum, 1, MPI_LONG_DOUBLE, i, 0, 1, MPI_LONG_DOUBLE, win);
        }
    } else {
        // Use MPI_Get to receive global sum from rank 0
        MPI_Get(&recv_sum, 1, MPI_LONG_DOUBLE, 0, 0, 1, MPI_LONG_DOUBLE, win);
    }

    // End the first fence with a barrier
    MPI_Barrier(MPI_COMM_WORLD);

    // Print result only from rank 0
    if (rank == 0) {
        auto end_time = chrono::steady_clock::now(); // End time
        auto elapsed_time = chrono::duration<double>(end_time - start_time).count();

        cout << "PI is approximately " << setprecision(50) << recv_sum << ", Error is " << fabsl(recv_sum - PI25DT) << endl;
        cout << "Runtime: " << elapsed_time << " seconds" << endl;
    }

    MPI_Win_free(&win);
    MPI_Finalize();
    return 0;
}

